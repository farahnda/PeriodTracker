{{-- filepath: resources/views/article/index.blade.php --}}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Article List</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" />
</head>
<body>
<div class="container mt-5">
    <h3 class="text-center my-4">Daftar Artikel</h3>
    <hr>
    <div class="card border-0 shadow-sm rounded">
        <div class="card-body">
            <a href="{{ route('articles.create') }}" class="btn btn-success mb-3">TAMBAH ARTIKEL</a>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Judul</th>
                        <th>Penulis</th>
                        <th>Gambar</th>
                        <th>Konten</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($articles as $article)
                    <tr>
                        <td>{{ $article->id }}</td>
                        <td>{{ $article->title }}</td>
                        <td>{{ $article->author }}</td>
                        <td>
                            @if($article->image_url)
                                <img src="{{ $article->image_url }}" alt="Gambar Artikel" style="max-height: 80px;">
                            @else
                                <span>Tidak ada gambar</span>
                            @endif
                        </td>
                        <td>{{ $article->content }}</td>
                        <td class="text-center">
                            <form action="{{ route('articles.destroy', $article->id) }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus artikel ini?');">
                                <a href="{{ route('articles.show', $article->id) }}" class="btn btn-sm btn-dark">SHOW</a>
                                <a href="{{ route('articles.edit', $article->id) }}" class="btn btn-sm btn-primary">EDIT</a>
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger">HAPUS</button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="text-center">Belum ada artikel tersedia.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>

            {{-- Jika kamu pakai pagination, ganti get() di controller dengan paginate() --}}
            {{-- Contoh: $articles = Article::latest()->paginate(10); --}}
            {{-- {{ $articles->links('vendor.pagination.bootstrap-4') }} --}}
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
@if(session()->has('success'))
    toastr.success('{{ session('success') }}', 'BERHASIL!');
@elseif(session()->has('error'))
    toastr.error('{{ session('error') }}', 'GAGAL!');
@endif
</script>
</body>
</html>